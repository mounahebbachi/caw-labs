function exf(s, n) {
    for (let i = 0; i < n; i++) {
        console.log(s);
    }
}

// Calling the function with specified arguments
exf("echo", 5);
exf("JS from server", 10);
