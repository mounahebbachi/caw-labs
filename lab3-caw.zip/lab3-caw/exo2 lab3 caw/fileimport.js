


const { mean } = require('./notation');


const scores = [15, 20, 25, 30, 35];
console.log("The mean score is:", mean(scores));
